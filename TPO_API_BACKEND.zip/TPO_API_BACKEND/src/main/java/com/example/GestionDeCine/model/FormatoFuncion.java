package com.example.GestionDeCine.model;

/** Formato de proyeccion de una {@link Funcion}. */
public enum FormatoFuncion {
    DOS_D,
    TRES_D,
    CUATRO_DX
}
