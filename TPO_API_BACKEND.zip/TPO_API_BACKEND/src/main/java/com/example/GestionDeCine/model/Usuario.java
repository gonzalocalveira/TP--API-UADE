package com.example.GestionDeCine.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad de dominio: un usuario del sistema (cliente, empleado o
 * administrador). El @Enumerated(EnumType.STRING) guarda "CLIENTE" /
 * "EMPLEADO" / "ADMINISTRADOR" como texto en la columna "rol" en vez de un
 * numero ordinal, para que la base de datos sea legible y no se rompa si
 * el enum Rol cambia de orden.
 *
 * Decision de diseño: Usuario NO tiene una referencia directa a Membresia.
 * La relacion es 1 a 1 pero el "dueño" de la relacion (quien tiene la FK)
 * es Membresia (columna usuario_id). Esto evita una relacion bidireccional
 * Usuario<->Membresia, que con Lombok (@Data genera equals/hashCode/toString)
 * y con la serializacion JSON de Jackson terminaria en referencias
 * circulares infinitas (Usuario.toString() -> Membresia.toString() ->
 * Usuario.toString() -> ...). Para consultar la membresia de un usuario se
 * usa MembresiaRepository.findByUsuarioId(id).
 */
@Entity
@Table(name = "usuarios", uniqueConstraints = {
        @UniqueConstraint(columnNames = "mail"),
        @UniqueConstraint(columnNames = "dni")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "El nombre y apellido es obligatorio")
    private String nombreApellido;

    @NotNull(message = "El DNI es obligatorio")
    @Positive(message = "El DNI debe ser un numero positivo")
    private Integer dni;

    @NotNull(message = "La fecha de nacimiento es obligatoria")
    @Past(message = "La fecha de nacimiento debe ser anterior a hoy")
    private LocalDate fechaNacimiento;

    @NotBlank(message = "El mail es obligatorio")
    @Email(message = "El mail no tiene un formato valido")
    private String mail;

    @NotBlank(message = "La password es obligatoria")
    @Size(min = 4, message = "La password debe tener al menos 4 caracteres")
    private String password;

    private boolean isSocio;

    @NotNull(message = "El rol es obligatorio")
    @Enumerated(EnumType.STRING)
    private Rol rol;
}
