package com.example.GestionDeCine.model;

/** Categorias de {@link Membresia} que puede tener un socio del cine. */
public enum TipoMembresia {
    CLASSIC,
    GOLD,
    BLACK
}
